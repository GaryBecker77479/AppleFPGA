toverilog.exe

This program is designed to convert binary ROM files to the format needed for Xilinx internal block memories for the fpga_apple project. This program will run in a pure DOS environment or in a DOS box under any version of Windows. To use the program, enter the command:

toverilog input output *start **length

  *start should be entered with 4 hex digits
 **length is optional and is entered in hex


The input file if the binary ROM file that you want to convert. The output file is the verilog that you want to write the verilog code into. This file does not need to exist. If it does not exist, it will be created. If it exists, it will be overwritten and all existing data will be lost.

The start parameter is the starting position (in hex) where you want to start the conversion. The length parameter is optional, and provides a way to convert shorter ROM files. If the length is not given, the default value of 0800 (2048 bytes) is used. This is the maximum that the fpga_apple ROM files can accept.

The C language source code is included in this compressed file.
